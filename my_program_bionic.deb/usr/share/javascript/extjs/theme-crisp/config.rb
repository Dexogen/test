Compass.add_project_configuration('../../../classic/theme-crisp/sass/config.rb')
